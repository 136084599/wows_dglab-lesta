API_VERSION = 'API_v1.0'
API_NAME = 'ExportHPAndDied'

import time
import datetime
from xml.dom import minidom

playerShipId = 0
LOG_FILE = 'damage_log.txt'

isdied = False
isInBattle = False
def get_self_ship_id(player_info):
    try:
        return getattr(player_info, 'shipId')
    except AttributeError:
        return 0

def append_damage_record(damage,isDied=False):
    with open(LOG_FILE, 'a') as f:
        timestamp = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S.%f')
        f.write("{},{},isDied:{}\n".format(timestamp, damage, isDied))

def onReceiveDamagesOnShip(vicId, damages):
    if vicId == playerShipId:
        append_damage_record(damages)
        
def init_log(max_health):
    global isdied
    with open(LOG_FILE, 'w') as f:
        f.write("MaxHealth,{}\n".format(max_health))
def clear_log():
    with open(LOG_FILE, 'w') as f:
        pass
CurrentShip = None
def isDied():
    global isdied,isInBattle,CurrentShip
    if not isInBattle:
        return
    
    if isdied:
        return
    
    if not CurrentShip:
        CurrentShip = battle.getSelfPlayerShip()
        if not CurrentShip:
            utils.logInfo('CurrentShip is not available yet.')
            return
        else:
            utils.logInfo('CurrentShip obtained: {}'.format(CurrentShip))
    if CurrentShip.isAlive() == False:
        isdied = True
        utils.logInfo('Player has died.')
        append_damage_record(0, isDied=True)

def onBattleStart(*args, **kwargs):
    global playerShipId,currentTickHandle,isInBattle,isdied
    PlayerInfo = battle.getSelfPlayerInfo()
    playerShipId = get_self_ship_id(PlayerInfo)
    isdied = False
    isInBattle = True
    max_health = getattr(PlayerInfo, 'maxHealth', 0)
    init_log(max_health)
    utils.logInfo('onBattleStart playerShipId: {}, maxHealth: {}'.format(playerShipId, max_health))

def onBattleQuit(*args, **kwargs):
    global currentTickHandle,isInBattle,isdied,CurrentShip
    clear_log()
    isInBattle = False
    CurrentShip = None
    isdied = False
    utils.logInfo('onBattleQuit')
    

callbacks.perTick(isDied)
devmenu.enable()
events.onBattleQuit(onBattleQuit)
events.onBattleStart(onBattleStart)
events.onReceiveDamagesOnShip(onReceiveDamagesOnShip)